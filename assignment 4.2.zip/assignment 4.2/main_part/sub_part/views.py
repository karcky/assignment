from django.contrib import messages
from django.shortcuts import redirect, render
from . models import Imageadd

def index(request):
    return render(request,'index.html')


def adding(request):
    if request.method == 'POST':
        prod = Imageadd()
        prod.title= request.POST.get('title')
        if len(request.FILES) != 0:
            prod.image = request.FILES['imagefile']

        prod.save()
        messages.success(request,"saved")
        return redirect(index)    
       
    return render(request, 'open.html')

def opened(request):
    prodects=Imageadd.objects.all()
    context={'prodects':prodects}
    return render(request,'open.html', context)
    